(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.an_TextInput = function(options) {
	this.initialize();
	this._element = new $.an.TextInput(options);
	this._el = this._element.create();
}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,100,22);

p._tick = _tick;
p._handleDrawEnd = _handleDrawEnd;
p._updateVisibility = _updateVisibility;
p.draw = _componentDraw;



(lib.Symbol3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CCFF00").s().p("AhUHRQgqgKgygaQgWgLhCglIh7hHQgvgbgYgRQgmgbgXgdQgrg3gHhPQgHhHAXhLQARg6AohMQAvhWAXgsIAYgtQAOgYAPgRQAiglAygNQATgFAZgBQAQgBAeABQBpABBoADQA1ACAbACQAsAEAiAIQA3AOA6AhQAuAaA5ArQBJA3ApAwQA3BAANBEQAIAmgDA2QgDBGgQA3QgVBDgxBMQgrBCgtAoQiAByjpACQhHAAgugMgAjuBtQgPAJgIAQQgHAPABASQABASAIAPQAVAlA/AZQA/AZBFAIQBEAIBDgJQAvgGAbgQQASgKAMgPQAMgRADgTIAAgBIAFABQAaABAUgJQASgJAKgSQAKgTgDgUQgDgTgQgPQgPgPgUgBIgSABQghAEgOAIQgNAIgHAOQgHANgBANQgIABgJADQgcAMgOAEQgUAGgcABQgQAAgggCQgvgEgZgFQgogIgbgTIgdgWQgSgMgPgBIgGgBQgOAAgNAIgAkYjEQgUAUABAbQACAcAVASQANALASACQASACAPgIQAVgLAIgaQAIgegQgYQgIgMgNgHQgNgHgOAAQgXABgSAQgACxjfQgUAJgKATQgJASAFAVQAFAVAQANQAQAMAVAAQAVgBAQgNQANgLAFgTQAFgSgGgQQgGgRgQgLQgPgLgSgBQgLAAgMAFg");
	this.shape.setTransform(69.2834,60.1167);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AiLJBQgugOg2gcQgegQhBgmIiJhSQgzgfgWgQQgogcgZgcQgmgrgWg5QgUg2gDg+QgGhmAqiAQASg2AZg6IAcg8QAfhAAegsQAmg4AsglQBBg3BKgPQAbgGAlgBIBCAAQDOAEAXABQCCAJBbAmQA2AWA7ApQAnAaBBAzQA6AuAcAdQAxA1AeBIQAcBEAFBMQAKCNhCCUQgyBwhSBUQhXBahsApQg2AWhQAOQhOANhFAAQhbAAhMgYgAj2ncQgZABgUAFQgyANghAlQgPARgPAYIgYAtQgWAsgwBWQgoBMgRA6QgWBLAGBHQAIBPArA3QAXAdAmAbQAYARAvAbIB7BHQBBAlAXALQAyAaApAKQAuAMBIAAQDpgCB/hyQAugoAqhCQAyhMAUhDQAQg3AEhGQACg2gHgmQgOhEg2hAQgpgwhJg3Qg5grgugaQg7ghg3gOQgigIgsgEQgagCg1gCQhogDhqgBIgSgBIgbABgAgsEnQhEgIhAgZQg/gZgUglQgIgPgBgSQgCgSAIgPQAHgQAQgJQAQgJARACQAPABARAMIAeAWQAbATAnAIQAZAFAwAEQAfACARAAQAbgBAVgGQAOgEAbgMQAKgDAIgBQAAgNAHgNQAIgOANgIQAOgIAggEIATgBQATABAQAPQAPAPADATQADAUgKATQgKASgSAJQgTAJgagBIgGgBIAAABQgCATgNARQgMAPgRAKQgbAQgwAGQgiAFgjAAQggAAgigEgAj2haQgSgCgNgLQgWgSgBgcQgCgbAVgUQARgQAYgBQAOAAANAHQAMAHAIAMQARAYgJAeQgHAagWALQgLAGgNAAIgIAAgACih6QgQgNgEgVQgFgVAJgSQAKgTATgJQANgFALAAQASABAPALQAPALAGARQAGAQgEASQgFATgOALQgPANgWABIgBAAQgUAAgQgMg");
	this.shape_1.setTransform(69.4033,60.1372);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol3, new cjs.Rectangle(0,0,138.8,120.3), null);


(lib.Symbol2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Symbol3();
	this.instance.setTransform(69.4,60.1,1,1,0,0,0,69.4,60.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({rotation:5.2174},0).wait(1).to({rotation:10.4348,x:69.35},0).wait(1).to({rotation:15.6522,x:69.4},0).wait(1).to({rotation:20.8696},0).wait(1).to({rotation:26.087,x:69.35,y:60.15},0).wait(1).to({rotation:31.3043,y:60.1},0).wait(1).to({rotation:36.5217},0).wait(1).to({rotation:41.7391,x:69.4,y:60.15},0).wait(1).to({rotation:46.9565,y:60.1},0).wait(1).to({rotation:52.1739},0).wait(1).to({rotation:57.3913,x:69.35,y:60.15},0).wait(1).to({rotation:62.6087,x:69.4,y:60.1},0).wait(1).to({rotation:67.8261},0).wait(1).to({rotation:73.0435,x:69.35,y:60.15},0).wait(1).to({rotation:78.2609},0).wait(1).to({rotation:83.4783,x:69.4},0).wait(1).to({rotation:88.6957,y:60.1},0).wait(1).to({rotation:93.913,x:69.35,y:60.15},0).wait(1).to({rotation:99.1304,x:69.4,y:60.05},0).wait(1).to({rotation:104.3478,y:60.1},0).wait(1).to({rotation:109.5652,x:69.35,y:60.05},0).wait(1).to({rotation:114.7826,x:69.4},0).wait(1).to({rotation:120,x:69.35},0).wait(1).to({rotation:125.2174,x:69.4,y:60.1},0).wait(1).to({rotation:130.4348,y:60.05},0).wait(1).to({rotation:135.6522,x:69.35},0).wait(1).to({rotation:140.8696,y:60.1},0).wait(1).to({rotation:146.087,y:60.05},0).wait(1).to({rotation:151.3043},0).wait(1).to({rotation:156.5217,y:60.1},0).wait(1).to({rotation:161.7391},0).wait(1).to({rotation:166.9565,x:69.4,y:60.05},0).wait(1).to({rotation:172.1739,x:69.35},0).wait(1).to({rotation:177.3913},0).wait(1).to({rotation:182.6087},0).wait(1).to({rotation:187.8261,x:69.4},0).wait(1).to({rotation:193.0435,x:69.35,y:60.1},0).wait(1).to({rotation:198.2609,x:69.4},0).wait(1).to({rotation:203.4783},0).wait(1).to({rotation:208.6957,x:69.35},0).wait(1).to({rotation:213.913,x:69.4,y:60.05},0).wait(1).to({rotation:219.1304,y:60.1},0).wait(1).to({rotation:224.3478,x:69.35,y:60.05},0).wait(1).to({rotation:229.5652,x:69.4,y:60.1},0).wait(1).to({rotation:234.7826},0).wait(1).to({rotation:240},0).wait(1).to({rotation:245.2174,x:69.35},0).wait(1).to({rotation:250.4348,x:69.4,y:60.05},0).wait(1).to({rotation:255.6522,x:69.35},0).wait(1).to({rotation:260.8696,x:69.4,y:60.1},0).wait(1).to({rotation:266.087,x:69.35,y:60.05},0).wait(1).to({rotation:271.3043,x:69.4},0).wait(1).to({rotation:276.5217,y:60.1},0).wait(1).to({rotation:281.7391},0).wait(1).to({rotation:286.9565,x:69.45},0).wait(1).to({rotation:292.1739},0).wait(1).to({rotation:297.3913},0).wait(1).to({rotation:302.6087},0).wait(1).to({rotation:307.8261,x:69.4},0).wait(1).to({rotation:313.0435,y:60.05},0).wait(1).to({rotation:318.2609,x:69.45,y:60.1},0).wait(1).to({rotation:323.4783,x:69.4},0).wait(1).to({rotation:328.6957,x:69.45},0).wait(1).to({rotation:333.913},0).wait(1).to({rotation:339.1304,x:69.4},0).wait(1).to({rotation:344.3478,x:69.45},0).wait(1).to({rotation:349.5652},0).wait(1).to({rotation:354.7826,x:69.4},0).wait(1).to({rotation:360},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-9.8,139.8,139.8);


// stage content:
(lib.ItextExtclass = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.an_TextInput({'id': '', 'value':'', 'disabled':false, 'visible':true, 'class':'ui-textinput'});

	this.instance.setTransform(362,480.95,1,1,0,0,0,50,11);

	this.texto = new cjs.Text("", "bold 71px 'Times New Roman'", "#00CCFF");
	this.texto.name = "texto";
	this.texto.lineHeight = 81;
	this.texto.lineWidth = 100;
	this.texto.alpha = 0.69411765;
	this.texto.parent = this;
	this.texto.setTransform(449,317.7);

	this.instance_1 = new lib.Symbol2();
	this.instance_1.setTransform(108.15,317.9,1,1,0,0,0,69.4,60.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.texto},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(550.8,641.8,0.20000000000004547,-149.29999999999995);
// library properties:
lib.properties = {
	id: '57A8D37F7052014BA11DA5BFE6B79416',
	width: 1024,
	height: 768,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"https://code.jquery.com/jquery-3.4.1.min.js?1690277388076", id:"lib/jquery-3.4.1.min.js"},
		{src:"components/sdk/anwidget.js?1690277388076", id:"sdk/anwidget.js"},
		{src:"components/ui/src/textinput.js?1690277388076", id:"an.TextInput"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['57A8D37F7052014BA11DA5BFE6B79416'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
function _updateVisibility(evt) {
	var parent = this.parent;
	var detach = this.stage == null || this._off || !parent;
	while(parent) {
		if(parent.visible) {
			parent = parent.parent;
		}
		else{
			detach = true;
			break;
		}
	}
	detach = detach && this._element && this._element._attached;
	if(detach) {
		this._element.detach();
		this.dispatchEvent('detached');
		stage.removeEventListener('drawstart', this._updateVisibilityCbk);
		this._updateVisibilityCbk = false;
	}
}
function _handleDrawEnd(evt) {
	if(this._element && this._element._attached) {
		var props = this.getConcatenatedDisplayProps(this._props), mat = props.matrix;
		var tx1 = mat.decompose(); var sx = tx1.scaleX; var sy = tx1.scaleY;
		var dp = window.devicePixelRatio || 1; var w = this.nominalBounds.width * sx; var h = this.nominalBounds.height * sy;
		mat.tx/=dp;mat.ty/=dp; mat.a/=(dp*sx);mat.b/=(dp*sx);mat.c/=(dp*sy);mat.d/=(dp*sy);
		this._element.setProperty('transform-origin', this.regX + 'px ' + this.regY + 'px');
		var x = (mat.tx + this.regX*mat.a + this.regY*mat.c - this.regX);
		var y = (mat.ty + this.regX*mat.b + this.regY*mat.d - this.regY);
		var tx = 'matrix(' + mat.a + ',' + mat.b + ',' + mat.c + ',' + mat.d + ',' + x + ',' + y + ')';
		this._element.setProperty('transform', tx);
		this._element.setProperty('width', w);
		this._element.setProperty('height', h);
		this._element.update();
	}
}

function _tick(evt) {
	var stage = this.stage;
	stage&&stage.on('drawend', this._handleDrawEnd, this, true);
	if(!this._updateVisibilityCbk) {
		this._updateVisibilityCbk = stage.on('drawstart', this._updateVisibility, this, false);
	}
}
function _componentDraw(ctx) {
	if(this._element && !this._element._attached) {
		this._element.attach($('#dom_overlay_container'));
		this.dispatchEvent('attached');
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;