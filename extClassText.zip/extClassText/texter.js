class Texter {
  constructor(root) {
    this.root = root;
    this.stage = this.root.stage;
    this.init();
  }

  init() {
    this.root.texto.text = "hello world";
  }
}



